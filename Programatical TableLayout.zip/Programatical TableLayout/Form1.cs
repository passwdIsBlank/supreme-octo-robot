﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Programatical_TableLayout
{
    public partial class Form1 : Form
    {
        string[] fields = new string[] { "Field1", "Field2", "Field1", "Field2", "Field1", "Field2", "Field1", "Field2", "Field1", "Field2", "Field1", "Field2" };
        public Form1()
        {
            InitializeComponent();
            foreach (string field in fields)
            {
                tableLayoutPanel1.RowCount++;
                tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));

                Label lbl = new Label() { Text = $"{field}{tableLayoutPanel1.RowCount - 1}" };
                TextBox textBox = new TextBox() { Width = 200 };

                TableLayoutPanel panel = new TableLayoutPanel();
                panel.RowCount = 1;
                panel.ColumnCount = 1;
                panel.AutoScroll = true;
                panel.Dock = DockStyle.Fill;

                panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 30));
                panel.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));

                panel.Controls.Add(textBox);

                tableLayoutPanel1.Controls.Add(lbl);
                tableLayoutPanel1.Controls.Add(panel);

                tableLayoutPanel1.ColumnCount = 2;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (Control control in tableLayoutPanel1.Controls)
            {
                if(control.GetType().Name.Equals("TableLayoutPanel"))
                {
                    TextBox textBox = new TextBox() { Width = 200 };
                    TableLayoutPanel panel = (TableLayoutPanel)control;

                    panel.RowCount++;
                    
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 30));
                    panel.Controls.Add(textBox);

                    panel.ColumnCount = 1;
                }
            }
        }

        private void btnMinus_Click(object sender, EventArgs e)
        {
            RemoveArbitraryRow(tableLayoutPanel1, tableLayoutPanel1.RowCount -2);
        }


        private void RemoveArbitraryRow(TableLayoutPanel panel, int rowIndex)
        {
            if (rowIndex >= panel.RowCount || rowIndex < 0)
            {
                return;
            }

            // delete all controls of row that we want to delete
            for (int i = panel.ColumnCount -1; i >= 0; i--)
            {
                var control = panel.GetControlFromPosition(i, rowIndex);
                panel.Controls.Remove(control);
            }

            // move up row controls that comes after row we want to remove
            for (int i = rowIndex + 1; i < panel.RowCount; i++)
            {
                for (int j = 0; j < panel.ColumnCount; j++)
                {
                    var control = panel.GetControlFromPosition(j, i);
                    if (control != null)
                    {
                        panel.SetRow(control, i - 1);
                    }
                }
            }

            var removeStyle = panel.RowCount - 1;

            if (panel.RowStyles.Count > removeStyle)
                panel.RowStyles.RemoveAt(removeStyle);

            panel.RowCount--;
        }
    }
}
